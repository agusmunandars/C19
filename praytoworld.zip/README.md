[![Netlify Status](https://api.netlify.com/api/v1/badges/a63153bc-ab0b-4399-9e3e-7950e4b27e99/deploy-status)](https://app.netlify.com/sites/covid19-indo/deploys)

# COVID19 Data
COVID-19 global data in your hand 
https://covid19.miftahafina.com

## Available Scripts
In the project directory, you can run:

- `yarn start`
- `yarn test`
- `yarn build`
- `yarn eject`

## Data Source
https://github.com/mathdroid/covid-19-api
